import React,{useEffect,useMemo,useState} from "react";
import {createRoot} from "react-dom/client";
import "./style.css";

const tasks=[
 {id:1,title:"Aufnahmebericht – Frau Schneider",type:"Aufnahmebericht",minutes:30,level:"B2",
  prompt:"Sie arbeiten auf einer geriatrischen Station. Frau Schneider, 82 Jahre, wird nach einem Sturz aus dem Krankenhaus übernommen. Verfassen Sie einen strukturierten Aufnahmebericht für das Pflege-Team.",
  facts:["82 Jahre, lebt allein","Sturz im Badezimmer; keine Fraktur","Hypertonie, Diabetes mellitus Typ 2","unsicherer Gang, Rollator","Hörgerät links","Tochter besucht sie täglich","Allergie: Penicillin","nimmt 5 Medikamente täglich"],
  points:["Aufnahmeanlass und Situation","Anamnese / relevante Diagnosen","Ressourcen und Risiken","Medikation / Allergien","Pflegebedarf und weitere Maßnahmen"]},
 {id:2,title:"Aufnahmebericht – Herr Weber",type:"Aufnahmebericht",minutes:30,level:"B2",
  prompt:"Herr Weber, 76 Jahre, wird zur Kurzzeitpflege aufgenommen. Schreiben Sie anhand der Informationen einen professionellen Aufnahmebericht.",
  facts:["76 Jahre, nach Hüftoperation","Mobilisation mit Unterarmgehstützen","Schmerz 5/10 bei Bewegung","isst selbstständig","benötigt Hilfe beim Duschen","Tochter ist Ansprechpartnerin","keine bekannten Allergien","Ziel: sichere Mobilisation"],
  points:["Aufnahmegrund","Mobilität und Schmerzen","Selbstständigkeit","Unterstützungsbedarf","Ziele und Maßnahmen"]},
 {id:3,title:"Pflegeübergabe – Frau Müller",type:"Übergabe",minutes:25,level:"B2",
  prompt:"Schreiben Sie eine schriftliche Übergabe für die nächste Schicht. Verwenden Sie die folgenden Informationen und formulieren Sie sachlich und präzise.",
  facts:["Frau Müller, 79 Jahre","COPD","Atemnot bei Belastung","SpO₂ aktuell 93 %","Inhalation um 14 Uhr","trinkt wenig","Sturzrisiko erhöht","ärztliche Kontrolle bei Verschlechterung"],
  points:["aktueller Zustand","Beobachtungen / Werte","durchgeführte Maßnahmen","Risiken","was die nächste Schicht beachten soll"]},
 {id:4,title:"Biografiebericht – Herr Yilmaz",type:"Biografiebericht",minutes:30,level:"B2",
  prompt:"Erstellen Sie einen kurzen Biografiebericht für das interprofessionelle Team. Achten Sie auf eine wertschätzende und pflegeorientierte Darstellung.",
  facts:["84 Jahre","stammt aus der Türkei","spricht Deutsch und Türkisch","war 40 Jahre Bäcker","mag klassische Musik","Familie ist sehr wichtig","benötigt Ruhe beim Essen","wünscht männliche Pflegekraft bei Körperpflege"],
  points:["Herkunft / Sprache","Beruf und Lebensgeschichte","Interessen","Gewohnheiten","individuelle Wünsche"]},
];

const redemittel={
"Einleitung":["Herr/Frau … wurde am … auf unsere Station aufgenommen.","Der Patient / die Patientin wurde zur … aufgenommen.","Bei der Aufnahme zeigte sich folgende Situation:"],
"Zustand":["Der Allgemeinzustand ist …","Der Patient ist zeitlich, örtlich und situativ orientiert.","Es besteht ein erhöhtes Risiko für …","Bei Belastung kommt es zu …"],
"Maßnahmen":["Es wurde … durchgeführt.","Zur Unterstützung wurde …","Die Mobilisation erfolgt mit …","Die Vitalzeichen werden regelmäßig kontrolliert."],
"Übergang":["Darüber hinaus ist zu beachten, dass …","Im weiteren Verlauf sollte …","Für die nächste Schicht ist wichtig, dass …"],
"Schluss":["Zusammenfassend lässt sich feststellen, dass …","Bei einer Verschlechterung des Zustands ist unverzüglich …","Weitere Maßnahmen werden entsprechend der ärztlichen Anordnung durchgeführt."]
};

function App(){
 const [taskId,setTaskId]=useState(1),[text,setText]=useState(""),[running,setRunning]=useState(false),[seconds,setSeconds]=useState(1800),[result,setResult]=useState(null),[tab,setTab]=useState("task");
 const task=tasks.find(x=>x.id===taskId);
 useEffect(()=>{if(!running)return; const t=setInterval(()=>setSeconds(s=>s<=1?(setRunning(false),0):s-1),1000);return()=>clearInterval(t)},[running]);
 const mm=String(Math.floor(seconds/60)).padStart(2,"0"), ss=String(seconds%60).padStart(2,"0");
 const words=text.trim()?text.trim().split(/\s+/).length:0;
 const evaluate=()=>{
   const lower=text.toLowerCase();
   const coverage=task.points.map(p=>({p,ok:lower.includes(p.split(" ")[0].toLowerCase())||text.length>180}));
   const errors=[];
   if(words<100) errors.push("Der Text ist sehr kurz. Für eine prüfungsnahe Antwort sollten die relevanten Informationen vollständig und zusammenhängend dargestellt werden.");
   if(!/[.!?]/.test(text)) errors.push("Achte auf vollständige Sätze und klare Satzzeichen.");
   if(!/(der|die|das|den|dem|ein|eine|einer)\\s+\\w+/i.test(text)) errors.push("Überprüfe Artikel und Kasus.");
   if(!/(weil|daher|deshalb|außerdem|darüber hinaus|jedoch|während|obwohl|zusammenfassend)/i.test(text)) errors.push("Baue mehr Konnektoren ein, um B2-Niveau sichtbar zu machen.");
   const grammar=Math.max(0,Math.min(5,5-(errors.length*.5)));
   const content=Math.max(0,Math.min(5,words>=220?5:words>=160?4:words>=100?3:2));
   const structure=Math.max(0,Math.min(5,/[\\n]/.test(text)?5:4));
   const vocab=Math.max(0,Math.min(5,/(Aufnahme|Patient|Pflege|Maßnahmen|Zustand|Risiko|Mobilisation)/i.test(text)?5:3));
   const total=grammar+content+structure+vocab;
   setResult({grammar,content,structure,vocab,total,errors,coverage});
   setTab("result");
 };
 const download=()=>{
   const blob=new Blob([text],{type:"text/plain;charset=utf-8"}),a=document.createElement("a");
   a.href=URL.createObjectURL(blob);a.download=`telc-b2-pflege-${task.id}.txt`;a.click();
 };
 return <div className="app">
  <header><div><div className="brand">TELC B2 PFLEGE</div><div className="sub">Schreiben · Prüfungstrainer</div></div><div className={"timer "+(seconds<300?"danger":"")}>⏱ {mm}:{ss}</div></header>
  <main>
   <aside><h3>Aufgaben</h3>{tasks.map(t=><button className={t.id===taskId?"active":""} onClick={()=>{setTaskId(t.id);setResult(null);setTab("task")}} key={t.id}><b>{t.type}</b><span>{t.title}</span><small>{t.minutes} Min. · B2</small></button>)}
   <div className="sidebox"><b>Prüfungsmodus</b><p>Arbeite zuerst ohne Redemittel. Nutze die Hinweise erst zur Korrektur.</p></div></aside>
   <section>
    <nav><button className={tab==="task"?"on":""} onClick={()=>setTab("task")}>Aufgabe</button><button className={tab==="write"?"on":""} onClick={()=>setTab("write")}>Schreiben</button><button className={tab==="result"?"on":""} disabled={!result} onClick={()=>setTab("result")}>Auswertung</button></nav>
    {tab==="task"&&<div className="card"><div className="eyebrow">TELC B2 PFLEGE · {task.type}</div><h1>{task.title}</h1><p className="prompt">{task.prompt}</p><h3>Informationen</h3><ul>{task.facts.map((f,i)=><li key={i}>{f}</li>)}</ul><h3>Dein Bericht sollte enthalten</h3><div className="chips">{task.points.map(p=><span key={p}>{p}</span>)}</div><button className="primary" onClick={()=>{setRunning(true);setTab("write")}}>Prüfung starten →</button></div>}
    {tab==="write"&&<div className="writegrid"><div className="card editor"><div className="editorhead"><b>{task.title}</b><span>{words} Wörter</span></div><textarea value={text} onChange={e=>setText(e.target.value)} placeholder="Schreiben Sie hier Ihren Aufnahmebericht …"/><div className="actions"><button onClick={()=>setRunning(false)}>Pause</button><button onClick={download}>Text speichern</button><button className="primary" onClick={evaluate}>Abgeben & bewerten</button></div></div>
      <div className="card"><h3>Redemittel</h3>{Object.entries(redemittel).map(([k,arr])=><details key={k}><summary>{k}</summary>{arr.map(x=><p className="phrase" key={x} onClick={()=>setText(t=>t+(t?" ":"")+x)}>{x}</p>)}</details>)}</div></div>}
    {tab==="result"&&result&&<div><div className="card result"><div><div className="eyebrow">TRAINER-AUSWERTUNG</div><h1>{result.total.toFixed(1)} / 20 Punkte</h1><p>Vorläufige automatische Einschätzung – nicht die offizielle telc-Bewertung.</p></div><div className="scoregrid">{[["Inhalt",result.content],["Struktur",result.structure],["Wortschatz",result.vocab],["Sprache",result.grammar]].map(([k,v])=><div><b>{v.toFixed(1)}</b><span>{k}</span></div>)}</div></div>
     <div className="two"><div className="card"><h3>Fehler & Hinweise</h3>{result.errors.length?result.errors.map(e=><div className="error">⚠ {e}</div>):<div className="good">✓ Keine groben Warnsignale gefunden.</div>}</div><div className="card"><h3>Abdeckung der Inhalte</h3>{result.coverage.map(x=><div className={x.ok?"check":"miss"}>{x.ok?"✓":"○"} {x.p}</div>)}</div></div>
     <div className="card"><h3>Nächster Schritt</h3><p>Überarbeite den Text anhand der Hinweise und reiche ihn erneut ein. Für eine echte Prüfungssimulation solltest du die Redemittel während des ersten Versuchs geschlossen lassen.</p><button className="primary" onClick={()=>setTab("write")}>Text verbessern</button></div>
    </div>}
   </section>
  </main>
 </div>
}
createRoot(document.getElementById("root")).render(<App/>);